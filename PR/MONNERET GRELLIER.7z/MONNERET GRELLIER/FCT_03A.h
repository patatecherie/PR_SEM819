#ifndef FCT_03A_H
#define FCT_03A_H
#include "FO-M3.h"
#include <string.h>

extern int running;
extern float temps;
extern unsigned char xdata Buffer[15];

//define function
void delay (void);
void arriver(void);
void compare_servo_H(void);
#endif