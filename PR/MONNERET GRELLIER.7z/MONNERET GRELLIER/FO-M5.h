#include "c8051F020.h"
#include <stdio.h>
#include <stdlib.h>

//define function
void Timer2_pulse(void);
void Count_or_Capt(void);
void Launch_Timer2(void);
unsigned int Ultrason_Dist(void);
void init_FO_M5();
