#ifndef MAIN_H
#define MAIN_H

#include "FCT_03A.h"
#include "FCT_05A.h"
//define function
void initialisation(void);
void config_clock(void);
void config_timer1(void);
void config_UART(void);
void serial0();

#endif