#ifndef FCT_05A_H
#define FCT_05A_H

#include <string.h>
extern unsigned char xdata Buffer[15];
#include "FO-M4.h"

#endif